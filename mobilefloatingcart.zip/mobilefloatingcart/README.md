# Mobile Floating Cart
 A simple module in development for Prestashop +1.7.

 ## Preview
<p align="center">
  <img src="./design/medias/preview.png">
</p>
